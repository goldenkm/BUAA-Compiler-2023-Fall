package Frontend.SyntaxComponents.AllStmt;

public class SemicolonStmt implements Stmt {
}

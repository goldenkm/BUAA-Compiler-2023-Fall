package Frontend.SyntaxComponents.AllStmt;

public interface BlockItem {
}

package Backend.Instructions;

public interface MipsInstruction {
    public String toMips();
}

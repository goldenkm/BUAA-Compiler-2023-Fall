package Frontend.SyntaxComponents.AllExp;

public interface UnaryBase {
}

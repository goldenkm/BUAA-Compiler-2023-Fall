package Backend;

public enum MipsInstrType {
    GLOBAL_VAR,
    ASCIIZ,
    COMMON,
}

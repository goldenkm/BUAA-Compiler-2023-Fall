package Middle.IrComponents;

public class Use {
    private Value value;

}

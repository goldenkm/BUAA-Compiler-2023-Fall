package Middle.IrComponents;

public class User extends Value {
}

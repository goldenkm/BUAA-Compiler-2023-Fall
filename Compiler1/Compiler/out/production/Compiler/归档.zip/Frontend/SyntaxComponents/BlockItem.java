package Frontend.SyntaxComponents;

public interface BlockItem {
}

package Frontend.SyntaxComponents.AllStmt;

import Frontend.SyntaxComponents.Stmt;

public class SemicolonStmt implements Stmt {
}

package Frontend.SyntaxComponents;

public interface UnaryBase {
}

package Frontend.SyntaxComponents;

public class ConstExp {
    private AddExp addExp;

    public void setAddExp(AddExp addExp) {
        this.addExp = addExp;
    }

}

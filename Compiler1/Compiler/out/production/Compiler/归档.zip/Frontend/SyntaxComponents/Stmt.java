package Frontend.SyntaxComponents;

public interface Stmt extends BlockItem {

}

package Frontend.SyntaxComponents;

import Frontend.SyntaxComponents.AllExp.AddExp;

public class ConstExp {
    private AddExp addExp;

    public void setAddExp(AddExp addExp) {
        this.addExp = addExp;
    }

}

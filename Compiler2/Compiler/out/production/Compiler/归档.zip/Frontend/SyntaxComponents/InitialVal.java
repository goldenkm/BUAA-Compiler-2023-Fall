package Frontend.SyntaxComponents;

public interface InitialVal {
}

package Frontend.SyntaxComponents.AllStmt;

public interface Stmt extends BlockItem {

}

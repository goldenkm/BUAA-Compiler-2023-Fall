package Frontend.SymbolManager;

public enum SymbolType {
    VAR, ARRAY1, ARRAY2, FUNC, ERROR
}
